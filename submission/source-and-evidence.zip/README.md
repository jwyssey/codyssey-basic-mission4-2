# Linux 장애 분석: OOM · CPU 과점유 · Deadlock

AI/SW Basic · 미션 4 Linux와 OS · 과제 2

**2026-09-18 실제 제공 앱으로 3종 장애와 변경 전후 총 6회 비교를 완료했다.** GitHub Issue 형식 보고서 3건, 스케줄링 보너스 분석, 원문 증거와 제출용 PDF를 포함한다. 수집 도구 테스트 11개와 실측 증거 검사 50개가 통과했다.

## 제출 파일

- **[통합 보고서 PDF](submission/linux-incident-report.pdf)** — 장애 분석 3건, 그래프, 보너스, 공통 Issue 템플릿. 원문 증거 ZIP도 PDF에 첨부했다.
- **[코드·원문 증거 ZIP](submission/source-and-evidence.zip)** — 소스, Markdown 보고서, 6회 로그·CSV·시스템 도구 출력, SHA256 목록. 제공 바이너리는 제외했다.
- [전체 결과와 제출 개요](submission/overview.md)

| 장애 | Before | After | 보고서 |
| --- | --- | --- | --- |
| OOM | MEMORY_LIMIT=64, 8.418초 후 MemoryGuard 종료 | 128로 상향, 17.536초 후 종료: 생존 약 2.08배 | [OOM](reports/01-oom.md) |
| CPU | CPU_MAX_OCCUPY=100, 27.302초 후 Watchdog 종료 | 40으로 하향, 90초 이상 생존·냉각 확인 | [CPU](reports/02-cpu.md) |
| Deadlock | MULTI_THREAD_ENABLE=true, 순환 락 대기·79.317초 로그 정체 | false, 90초 동안 작업·로그 진행 | [Deadlock](reports/03-deadlock.md) |
| 보너스 | A→B→C 순환과 Preempted/Resumed 로그 | 앱 수준 Round-Robin으로 추론 | [스케줄링](reports/04-scheduling.md) |

생존 연장·회피는 관측 범위의 결과다. 커널 OOM, 영구적인 누수 해결, 장기간 무장애, 응답 지연 개선까지 주장하지 않는다. 앱의 `Current Load`와 OS가 측정한 CPU 사용률은 구분했다.

## 재현

제공 ZIP의 `agent-leak-app-x86`을 `vendor/`에 추출했다. 원본은 수정하지 않았으며 [ZIP·바이너리 SHA256](evidence/artifact.json)을 보존했다. 다른 PC에서는 아키텍처에 맞는 교육기관 제공 파일을 준비한다.

```bash
# 저장소의 code 폴더에서 실행
chmod u+x vendor/agent-leak-app-x86

# 현재 PC처럼 기존 서비스가 15034를 쓰는 경우 독립 네트워크로 실행
unshare --user --map-current-user --net bash scripts/run-suite.sh \
  --app vendor/agent-leak-app-x86 --duration 90 --interval 0.1 \
  --snapshot-interval 5

# 한 건만 실행: 아래는 제출에 사용한 CPU Before와 같은 명령
unshare --user --map-current-user --net bash scripts/run-case.sh \
  --app vendor/agent-leak-app-x86 --case cpu-before \
  --duration 90 --interval 0.1 --snapshot-interval 5
```

실험에 사용한 명령 6개는 [manifest.json](evidence/manifest.json)에 있다. OOM·Deadlock 비교는 0.5초, CPU 비교는 0.1초 간격이었다. 위 suite 예시는 모든 케이스를 0.1초로 관측한다. 실행 시간과 부하 수치는 실행마다 달라질 수 있다.

Linux 일반 계정, Python 3.9 이상, Bash, `ps`, `top`, `ss`, `unshare`가 필요하다. 사용자 네임스페이스를 허용하지 않는 환경에서는 별도 Linux VM/컨테이너 안에서 `bash scripts/run-suite.sh ...`로 실행한다. 네트워크만 격리하며 CPU·메모리는 호스트와 공유한다. 기존 서비스·방화벽·cron을 변경하지 않았다.

### 비교 설정

| 실험 | MEMORY_LIMIT (MB) | CPU_MAX_OCCUPY (%) | MULTI_THREAD_ENABLE |
| --- | ---: | ---: | --- |
| oom-before | 64 | 100 | false |
| oom-after | 128 | 100 | false |
| cpu-before | 512 | 100 | false |
| cpu-after | 512 | 40 | false |
| deadlock-before | 512 | 40 | true |
| deadlock-after | 512 | 40 | false |

실제 앱 로그를 통해 위 조건을 확정했다. CPU_MAX_OCCUPY는 이 앱에서 최대 부하 설정으로 관측됐고 100→40으로 낮춰 보호 종료를 회피했다. 한 쌍 안에서는 해당 변수 하나만 바꿨다. 정상 관측 조합은 **512 / 40 / false**다.

## 코드와 증거

| 파일 | 역할 |
| --- | --- |
| [bin/monitor.sh](bin/monitor.sh) | PID 또는 그룹별 구간 CPU·RSS·스레드·상태 기록 |
| [scripts/run-case.sh](scripts/run-case.sh) | 환경 생성, 단일 실험, 로그·스냅샷 보존, 실험 프로세스 정리 |
| [scripts/run-suite.sh](scripts/run-suite.sh) | 6개 비교 케이스 순차 실행 |
| [scripts/summarize-evidence.py](scripts/summarize-evidence.py) | 확정 실행 목록의 워커 통계·그래프 재생성 |
| [scripts/verify-evidence.py](scripts/verify-evidence.py) | 실제 증거의 원본·설정·종료 원인·비교 검증 |
| [scripts/build-submission.py](scripts/build-submission.py) | 보고서 PDF와 증거 ZIP 생성 |
| [templates/issue-report.md](templates/issue-report.md) | 명세의 4개 섹션을 갖춘 공통 템플릿 |
| [evidence/manifest.json](evidence/manifest.json) | 제출에 사용하는 정확한 실행 목록·명령 |
| [evidence/comparison.json](evidence/comparison.json) | 원문 CSV에서 계산한 워커별 통계 |
| [docs/EXPERIMENTS.md](docs/EXPERIMENTS.md) | 실행 방법·지표·종료 결과 해석 |
| [docs/VERIFICATION.md](docs/VERIFICATION.md) | 검증 범위와 한계 |

실험마다 `AGENT_HOME/upload_files`, `api_keys/secret.key`, 로그 폴더를 만들고 명세의 테스트 키 `agent_api_key_test`와 필수 환경변수를 구성한다. 환경변수는 해당 프로세스에만 적용된다.

각 `evidence/runs/<시각>-<실험>-<고유 번호>/`에는 `metadata.json`, `console.log`, `app-logs/`, `metrics.csv`, `monitor.log`, `snapshots.txt`, `log-sizes.jsonl`, `result.json`, `summary.json`을 보존한다. 소켓 소유 워커를 실행기와 구분하고, 여러 PID 또는 스레드의 RSS를 중복 합산하지 않는다.

수집기는 종료 직전 문구를 보존하도록 PTY로 앱을 실행한다. `observation_timeout`은 관찰 상한 이후 수집기가 종료한 것이며 앱 Watchdog 종료와 다르다. `result.json`에 정리 신호를 따로 기록한다. 초기 OOM 비교는 파이프 수집본으로도 MemoryGuard의 핵심 로그가 보존됐으며, 수집 방식의 차이는 manifest에 명시했다.

## 검증과 PDF 재생성

```bash
bash tests/test_monitor.sh
python3 scripts/summarize-evidence.py
python3 scripts/verify-evidence.py
python3 scripts/build-submission.py
```

수집·테스트·증거 검증은 Python 표준 라이브러리를 사용한다. 그래프에는 Matplotlib, PDF에는 PyMuPDF·Python-Markdown과 한글 폰트가 추가로 필요하다. 현재 환경의 설치된 패키지와 맑은 고딕 TTF 폰트를 사용했다. 다른 환경에서는 `--font /경로/한글폰트.ttf`를 지정한다.

[도구 테스트 11개](evidence/tool-tests.txt), [실측 검사 50개](evidence/verification.txt), [수행 상태](evidence/STATUS.md)를 확인할 수 있다. 원격 저장소 게시나 GitHub Issue 등록은 하지 않았으며, 제출용 PDF와 ZIP은 로컬 `submission/`에 있다.
